#ifndef _CRC_16_H_
#define _CRC_16_H_

#include "config.h"

#define false	0
#define true  1

enum {
    CMD_START_FLAG_INDEX = 0,
    CMD_LENGTH_INDEX,   //1
    CMD_CMD_INDEX,      //2
    CMD_PARA_INDEX      //3
};
#define CMD_END_FLAG_LEN        1

#define CRC16_LENGTH    2

//#define NO_CRC_TABLE      //��ʹ�ò��ұ�

#ifndef NO_CRC_TABLE
//#define TABLE_IN_MEMORY     //CRC��������ڴ�
#endif

#ifdef TABLE_IN_MEMORY
void init_crc_table(void);
#endif



u16 compute_crc_16(u8 *dataw, u32 length);
char check_crc16(u8 *dataw, u32 length);




#endif

