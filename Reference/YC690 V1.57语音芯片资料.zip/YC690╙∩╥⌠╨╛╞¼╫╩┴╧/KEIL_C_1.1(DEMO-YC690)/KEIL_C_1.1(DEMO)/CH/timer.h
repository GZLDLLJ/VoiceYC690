
/*------------------------------------------------------------------*/
/* --- STC MCU International Limited -------------------------------*/
/* --- STC 1T Series MCU RC Demo -----------------------------------*/
/* --- Mobile: (86)13922805190 -------------------------------------*/
/* --- Fax: 86-0513-55012956,55012947,55012969 ---------------------*/
/* --- Tel: 86-0513-55012928,55012929,55012966 ---------------------*/
/* --- Web: www.GXWMCU.com -----------------------------------------*/
/* --- QQ:  800003751 ----------------------------------------------*/
/* If you want to use the program or the program referenced in the  */
/* article, please specify in which data and procedures from STC    */
/*------------------------------------------------------------------*/

#ifndef	__TIMER_H
#define	__TIMER_H

#define MAIN_Fosc		22118400L	//������ʱ��
#include	"STC15Fxxxx.H"

#define	Timer0						0
#define	Timer1						1
#define	Timer2						2
#define	Timer3						3
#define	Timer4						4

#define	TIM_16BitAutoReload			0
#define	TIM_16Bit					1
#define	TIM_8BitAutoReload			2
#define	TIM_16BitAutoReloadNoMask	3

#define	TIM_CLOCK_1T				0
#define	TIM_CLOCK_12T				1
#define	TIM_CLOCK_Ext				2

//��ʱ�����ýṹ��
typedef struct 
{
  u8  Mark;   //��ʱʱ����λ
  u16 Count;  //��ʱ����
  u16 Initial;//��ʱ����ֵ
} TIM_COUNT;

typedef struct
{
	u8	TIM_Mode;		    //����ģʽ,  	TIM_16BitAutoReload,TIM_16Bit,TIM_8BitAutoReload,TIM_16BitAutoReloadNoMask
	u8	TIM_Polity;		  //���ȼ�����	PolityHigh,PolityLow
	u8	TIM_Interrupt;	//�ж�����		ENABLE,DISABLE
	u8	TIM_ClkSource;	//ʱ��Դ		TIM_CLOCK_1T,TIM_CLOCK_12T,TIM_CLOCK_Ext
	u8	TIM_ClkOut;		  //�ɱ��ʱ�����,	ENABLE,DISABLE
	u16	TIM_Value;		  //װ�س�ֵ
	u8	TIM_Run;		    //�Ƿ�����		ENABLE,DISABLE
} TIM_InitTypeDef;

u8	Timer_Inilize(u8 TIM, TIM_InitTypeDef *TIMx);

extern void	Timer_config(void);             //��ʼ��
extern void Delay100us(unsigned int _US);	  //��ʱ100us
extern void Delay1Ms(unsigned int _MS);	 	  //��ʱ1ms
extern void GetTimer(void);                 //��ȡʱ��,ѭ������



#define T100US_NUM    5     //100us ���λ����
#define T1MS_NUM      5     //1ms   ���λ����
#define T10MS_NUM     5     //10ms  ���λ����
#define T100MS_NUM    5     //100ms ���λ����
#define T1000MS_NUM   5     //1000ms���λ���� 
extern u8 TIM_100us[];      //100us
extern u8 TIM_1ms[];        //1ms
extern u8 TIM_10ms[];       //10ms
extern u8 TIM_100ms[];      //100ms
extern u8 TIM_1000ms[];     //1000ms



#endif
