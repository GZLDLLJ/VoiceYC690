 
 
 
 

 
 I2C_HandleTypeDef I2cHandle;
 
 
 
void HAL_I2C_MspInit(I2C_HandleTypeDef *hi2c)
{

 RCC->CFGR3 |= RCC_I2C1CLKSOURCE_SYSCLK;

 GPIO_InitTypeDef  GPIO_InitStruct;
// static DMA_HandleTypeDef hdma_tx;
 RCC_PeriphCLKInitTypeDef  RCC_PeriphCLKInitStruct;

 /*##-1- Configure the I2C clock source. The clock is derived from the SYSCLK #*/
 RCC_PeriphCLKInitStruct.PeriphClockSelection = RCC_PERIPHCLK_I2Cx;
 RCC_PeriphCLKInitStruct.I2c1ClockSelection = RCC_I2CxCLKSOURCE_SYSCLK;
 HAL_RCCEx_PeriphCLKConfig(&RCC_PeriphCLKInitStruct);

 /*##-2- Enable peripherals and GPIO Clocks #################################*/
 /* Enable GPIO TX/RX clock */
 I2Cx_SCL_GPIO_CLK_ENABLE();
 I2Cx_SDA_GPIO_CLK_ENABLE();
 /* Enable I2Cx clock */
 I2Cx_CLK_ENABLE();

 /* Enable DMAx clock */
 I2Cx_DMA_CLK_ENABLE();   
 /*##-3- Configure peripheral GPIO ##########################################*/
 /* I2C TX GPIO pin configuration  */
 GPIO_InitStruct.Pin	   = I2Cx_SCL_PIN;
 GPIO_InitStruct.Mode	   = GPIO_MODE_AF_OD;
 GPIO_InitStruct.Pull	   = GPIO_PULLUP;
 GPIO_InitStruct.Speed	   = GPIO_SPEED_FREQ_HIGH;
 GPIO_InitStruct.Alternate = 0x04;
 HAL_GPIO_Init(I2Cx_SCL_GPIO_PORT, &GPIO_InitStruct);

 /* I2C RX GPIO pin configuration  */
 GPIO_InitStruct.Pin	   = I2Cx_SDA_PIN;
 GPIO_InitStruct.Alternate = 0x04;
 HAL_GPIO_Init(I2Cx_SDA_GPIO_PORT, &GPIO_InitStruct);




   /* NVIC for I2Cx */
//  HAL_NVIC_SetPriority(I2C1_IRQn, 0, 1);
//  HAL_NVIC_EnableIRQ(I2C1_IRQn);
}

#define I2C_ADDRESS        0x30F
#define I2C_TIMING      0xB042C3C7   //10kHz
//#define I2C_TIMING      0xB0425F63   //20kHz
//#define I2C_TIMING      0xB0423D41   //30kHz
//#define I2C_TIMING      0xB0422D31   //40kHz
//#define I2C_TIMING 		0xB0422327 //50KHz
//#define I2C_TIMING      0xB0420F13 //100kHz



void init_iic(void)
{
	/*##-1- Configure the I2C peripheral ######################################*/
  I2cHandle.Instance             = I2Cx;
  I2cHandle.Init.Timing          = I2C_TIMING;
  I2cHandle.Init.OwnAddress1     = I2C_ADDRESS;
  I2cHandle.Init.AddressingMode  = I2C_ADDRESSINGMODE_7BIT;
  I2cHandle.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  I2cHandle.Init.OwnAddress2     = 0xFF;
  I2cHandle.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  I2cHandle.Init.NoStretchMode   = I2C_NOSTRETCH_DISABLE;

  HAL_I2C_Init(&I2cHandle);
  HAL_I2CEx_ConfigAnalogFilter(&I2cHandle,I2C_ANALOGFILTER_ENABLE);

}


void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_OscInitTypeDef RCC_OscInitStruct;

  /* use HSE Oscillator for PLL clockSource and Activate PLL */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV1;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct)!= HAL_OK)
  {
    /* Initialization Error */
    while(1);
  }

  /* Select PLL as system clock source and configure the HCLK, PCLK1 clocks dividers */
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1)!= HAL_OK)
  {
    /* Initialization Error */
    while(1);
  }
}



int main(void)
{

	uint8 play_specify[] = {0x5A, 0x04, 0x0C, 0x00, 0x03, 0x01, 0x84, 0x3F, 0xA5};//播放指定曲目

  	HAL_Init();

	/* Configure the system clock to 48 MHz */
	SystemClock_Config();

	init_iic();


	HAL_I2C_Master_Transmit(&I2cHandle, (uint16_t)0xD0, play_specify, 9, 10000);
	 
	while (1)
	{

	}

}

















